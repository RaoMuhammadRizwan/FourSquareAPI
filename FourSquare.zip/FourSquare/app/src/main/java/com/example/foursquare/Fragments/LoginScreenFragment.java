package com.example.foursquare.Fragments;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.example.foursquare.R;
import com.example.foursquare.db.DatabaseHelper;
import com.example.foursquare.databinding.FragmentLoginScreenBinding;

import java.util.regex.Pattern;

public class LoginScreenFragment extends Fragment {
    private FragmentLoginScreenBinding binding;
    private DatabaseHelper databaseHelper;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentLoginScreenBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        databaseHelper = new DatabaseHelper(getActivity());

        binding.signInButton.setOnClickListener(v -> {
            String email = binding.emailEditText.getText().toString().trim();
            String password = binding.passwordEditText.getText().toString().trim();

            if (validateInputs(email, password)) {
                if (isLoginSuccessful(email, password)) {
                    navigateToHome();
                } else {
                    Toast.makeText(getActivity(), "Invalid email or password", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private boolean validateInputs(String email, String password) {
        if (email.isEmpty()) {
            binding.emailEditText.setError("Email cannot be empty");
            return false;
        }
        if (!isValidEmail(email)) {
            binding.emailEditText.setError("Invalid email format");
            return false;
        }
        if (password.isEmpty()) {
            binding.passwordEditText.setError("Password cannot be empty");
            return false;
        }
        if (password.length() < 6) {
            binding.passwordEditText.setError("Password must be at least 6 characters");
            return false;
        }
        return true;
    }

    private boolean isValidEmail(String email) {
        String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
        return Pattern.matches(emailPattern, email);
    }

    private boolean isLoginSuccessful(String email, String password) {
        Cursor cursor = databaseHelper.getUserByEmail(email);
        if (cursor != null && cursor.moveToFirst()) {
            @SuppressLint("Range") String storedPassword = cursor.getString(cursor.getColumnIndex("password"));
            cursor.close();
            return password.equals(storedPassword);
        }
        return false;
    }

    private void navigateToHome() {
        NavController navController = Navigation.findNavController(requireView());
        navController.navigate(R.id.action_loginScreenFragment_to_searchFragment2);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
