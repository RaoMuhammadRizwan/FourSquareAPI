package com.example.foursquare;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.example.foursquare.databinding.GriditemsBinding;

public class GridAdapter extends BaseAdapter {
    private Context context;
    private String[] itemNames;
    private int[] images; //

    public GridAdapter(Context context, String[] itemNames, int[] images) {
        this.context = context;
        this.itemNames = itemNames;
        this.images = images;
    }
    @Override
    public int getCount() {
        return 0;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        GriditemsBinding binding;
        if(convertView == null){
            LayoutInflater inflater = LayoutInflater.from(context);
            binding = GriditemsBinding.inflate(inflater, parent, false);
            convertView = binding.getRoot();
        } else {
            binding = GriditemsBinding.bind(convertView);
        }


        binding.imageView.setImageResource(images[position]);
        binding.textView.setText(itemNames[position]);

        return convertView; //
    }
}
