package com.example.foursquare.Fragments;

import android.app.DatePickerDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.example.foursquare.db.DatabaseHelper;
import com.example.foursquare.R;
import com.example.foursquare.databinding.FragmentLocalSignupBinding;

import java.util.Calendar;

public class localSignupFragment extends Fragment {

    private FragmentLocalSignupBinding binding;
    private DatabaseHelper databaseHelper;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentLocalSignupBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // gender spinner with a default value
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getActivity(),
                R.array.gender_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        binding.genderSpinner.setAdapter(adapter);
        binding.genderSpinner.setSelection(0);

        binding.birthdayEditText.setOnClickListener(v -> showDatePickerDialog());

        binding.signupButton.setOnClickListener(v -> {
            String firstName = binding.firstNameEditText.getText().toString().trim();
            String lastName = binding.lastNameEditText.getText().toString().trim();
            String email = binding.emailEditText.getText().toString().trim();
            String password = binding.passwordEditText.getText().toString().trim();
            String birthday = binding.birthdayEditText.getText().toString().trim();
            String phone = binding.phoneNumberEditText.getText().toString().trim();
            String gender = binding.genderSpinner.getSelectedItem().toString();

            if (validateInputs(firstName, lastName, email, password, birthday, gender)) {
                if (!isEmailAlreadyRegistered(email)) {
                    boolean isInserted = databaseHelper.addUser(firstName, lastName, email, password, birthday, phone, gender);
                    if (isInserted) {
                        Toast.makeText(getActivity(), "Signup successful!", Toast.LENGTH_SHORT).show();
                        navigateToLoginPage(view);
                    } else {
                        Toast.makeText(getActivity(), "Signup failed. Please try again.", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getActivity(), "Email already registered.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private boolean validateInputs(String firstName, String lastName, String email, String password, String birthday, String gender) {
        boolean isValid = true;

        if (TextUtils.isEmpty(firstName)) {
            binding.firstNameEditText.setError("First name is required");
            isValid = false;
        }

        if (TextUtils.isEmpty(lastName)) {
            binding.lastNameEditText.setError("Last name is required");
            isValid = false;
        }

        if (TextUtils.isEmpty(email)) {
            binding.emailEditText.setError("Email is required");
            isValid = false;
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            binding.emailEditText.setError("Enter a valid email address");
            isValid = false;
        }

        if (TextUtils.isEmpty(password)) {
            binding.passwordEditText.setError("Password is required");
            isValid = false;
        } else if (password.length() < 6) {
            binding.passwordEditText.setError("Password should be at least 6 characters");
            isValid = false;
        }

        if (TextUtils.isEmpty(birthday)) {
            binding.birthdayEditText.setError("Birthday is required");
            isValid = false;
        }

        if (gender.equals("Select Gender")) {
            Toast.makeText(getActivity(), "Please select a gender", Toast.LENGTH_SHORT).show();
            isValid = false;
        }

        return isValid;
    }

    private boolean isEmailAlreadyRegistered(String email) {
        Cursor cursor = databaseHelper.getUserByEmail(email);
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    private void showDatePickerDialog() {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(getActivity(),
                (view, year1, month1, dayOfMonth) -> binding.birthdayEditText.setText(dayOfMonth + "/" + (month1 + 1) + "/" + year1),
                year, month, day);
        datePickerDialog.show();
    }

    private void navigateToLoginPage(View view) {
        NavController navController = Navigation.findNavController(view);
        navController.navigate(R.id.action_localSignupFragment_to_loginScreenFragment);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
