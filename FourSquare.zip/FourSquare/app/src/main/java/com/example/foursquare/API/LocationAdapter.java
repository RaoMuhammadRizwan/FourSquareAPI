package com.example.foursquare.API;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.foursquare.R;

import java.util.List;

public class LocationAdapter extends RecyclerView.Adapter<LocationAdapter.LocationViewHolder> {
    private List<Location> locations;

    public LocationAdapter(List<Location> locations){
        this.locations = locations;
    }

    @NonNull
    @Override
    public LocationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_location, parent, false);
        return new LocationViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull LocationViewHolder holder, int position) {
        Location location = locations.get(position);
        holder.tvname.setText(location.getName());
        holder.tvaddress.setText(location.getAddress());

    }

    @Override
    public int getItemCount() {
        return 0;
    }

    static class LocationViewHolder extends RecyclerView.ViewHolder {
        TextView tvname;
        TextView tvaddress;

        public LocationViewHolder(@NonNull View itemView) {
            super(itemView);
            tvname = itemView.findViewById(R.id.tvLocationName);
            tvaddress = itemView.findViewById(R.id.tvLocationAddress);
        }
}}
